final login = "Log in";
final appbartext = "TyreShifter";
final forgotpassword = "Forgot Password?";
final enable_location = "Enable Location";
final availble_today = "Available Today";
final details = "Details";
final detail = "Detail";
final des = "Description";
final review = "Reviews";
final review_popup = "Review";
final see_all = "See All";
final send_req = "Send Request";
final tyreshift_immidiate = "Tyreshifter Immediately";
final done = "Done";
final payment = "Payment";
final immediate_req = "Immediately Request";
final service_detai = "Service Detail";
final paymen_rec = "Payment Receipt";
final payment_details = "Payment Detail";
final before_after = "Before and After ";
final give_review = "Give a review ";
final sent_reuest = "Your request has been sent.";
final view_req = "View My Requests";
final notification = "Notification";
final my_req = "My Request";
final in_progess = "In Progress ";
final completed = "Completed";
final msg = "Message";
final repeat_order = "Repeat Order";
final cancel_req = "Cancel Request";
final inbox = "Inbox";
final profile = "Profile";
final time = "Time";
final filter = "Filter";
final emailtxt = "Email";
final what_is_issue = "What is the issue...";
final write_comment = "Write Comment...";
final edit_profile = "Edit Profile";
final push_notification = "Push Notification";
final change_Password = "Change Password";
final faq = "Faq";
final Card_number = "Card number";
final Card_holder_name = "Card holder name";

final expirytxt = "Expiry";
final cvvtxt = "CVV";
final support = "Support";
final log_out = "Logout";
final update = "Upadte";
final send = "Send";
final home = "Home";
final calendertxt = "Calender";
final reserve = "Reserve";
final lets_get_started = "LETS GET STARTED";
final get_start_dmsg = "Sign up or log in to find out than Your best car";
final become_shifter = "Become a shifter";
final get_shifter = "Get a shifter";
final get_started = "Get Started";
final verify = "verify";
final verification = "Verification";
final create_account = "Create an account";
final register = "Register";
final continu = "Continue";
final enable_locationtxt = "Enable location";
final enable = "Enable";
final setup_price = "Setup Price";
final hii_welcome = "Hi! Welcome";
final hii_welcome_back = "Hi! Welcome Back";
final login_account_msg = "Log in to your account";
final sign_up_to_accmsg = "Signup to your account ";
final enter_emailtxt = "Enter Email";
final enter_company_nametxt = "Enter Company Name";
final enter_company_numbertxt = "Enter Company number";
final enter_birthday_txt = "Enter Birthday";
final password_txt = "Password";
final con_password_txt = "Confirm Password";
final about_us_txt = "About us";
final enterfull_name_txt = "Enter Full Name";
final enable_locatin_msg = "Choose your location to start find around you.";
final submit_order_early_msg = "Thank you are submit order early";
final verification_msg_txt =
    "Thanks for registrations you will be verified within 24hrs";
final req_des =
    "Thanks For the payment your payment is store with tyreshifter when your request will done we will send money to service provider";
final cancel_req_des = "Are you sure want to cancel request with Summers tyres";

//supplier sting
final Register_reqmsg =
    "You need to have the following information to complete the registration";
final welcome_tyreshifter = "Welcome Tyreshifter";
final welcome_tyreshifter_msg = "Welcome you have now been registered";
final always = "Always";
final set_availabilty = "Set Availability";
final availabilty = "Availability";
final how_many_work = "How many Workers?";
final latest_req = "Latest Requests";
final change_tyre = "Change My tyre ";
final completed_orders = "Completed orders ";
final accept = "Accept";
final reject = "Reject";
final working = "Working";
final my_booking = "My booking";
final Upload_Vehicle_photo = "Upload Vehicle photo";
final before = "Before";
final after = "After";
final withdraw = "Withdraw";
final personal_bal = "Personal Balance";
final withdraw_to = "Withdraw To";
final back_transfer = "Bank Transfer";
final withdraw_to_credit_card = "Withdraw To Credit card";
final change_availability = "Change Availability";
final edit_price = "Edit Price";
final view_booking_btn_txt = "View My Booking";
final complete = "Complete";
final booking_details = "Booking Details";
final upload_hms_card = "Upload HMS Card";
final i_agreetxt = "I agree with ";
final terms_condition = " terms and conditions";
final company = "Company";
final individual = "Individual Company (ENK)";
final Register_as = "Register As";
final welcome_1 = "Car jack";
final welcome_2 = "Wheel cross";
final welcome_3 = "Nutrunner";
final welcome_4 =
    "Make sure the bolts are on place by using a wheel cross to check before the tyreshift is completed. ";
final req_1 = "Your Hms Card ";
final req_2 = "Your business organisation number ";
final req_3 =
    "Your bank account with IBAN coding (this may be found on your bank web page) ";
final submit_msg_txt = "Thank you are submit order early";
final viewbookingmsg =
    "Thank you for accepting the order Your payment will be added to your account once the work is completed. Good luck!";
final cancel = "Cancel";
//image------
final enable_locationimg = "assets/enable_locationimg.png";
final reserver_shifterimg = "assets/shifter.png";
final crossimage = "assets/cross.png";
final logo = "assets/logo.png";
final service_img = "assets/service_image.png";
final tryeicon_img = "assets/tyre_icon.png";
final tryeicon_ = "assets/tyre_icon.png";
final detail_service_img = "assets/detail_service_image.png";
final paymentimg = "assets/payment.png";
final location_vector = "assets/location_Vector.png";
final calender = "assets/calender.png";
final vipps = "assets/Vipps.png";
final credit_card = "assets/credit_card.png";
final apple_icon = "assets/apple_icon.png";
final tyre_immidate = "assets/tyre_immidate.png";
final divider = "assets/divider.png";
final revserve_shifter = "assets/reserve_shifter.png";
final kmicon = "assets/kmicon.png";
final staricon = "assets/starticon.png";
final pdf = "assets/pdf.png";
final vertical = "assets/vertical_line.png";
final tick = "assets/tick.png";
final notification_blue = "assets/notification_blue.png";
final notification_pink = "assets/notification_pink.png";
final msg_icon = "assets/msg_icon.png";
final edit_icon = "assets/edit_icon.png";
final mail_icon = "assets/mail_icon.png";
final lock_icon = "assets/lock_icon.png";
final change_password_img = "assets/change_password_img.png";
final supportimg = "assets/support_icon.png";
final logo_without_tag = "assets/logowithout_tag.png";
final english = "assets/English.png";
final norway = "assets/norway.png";
final otpimg = "assets/otpimg.png";
final perosnimg = "assets/person.png";
final birthdayimg = "assets/birthday.png";
final location_globe = "assets/globe.png";

//supplier_image
final check_circle = "assets/check_circle.png";
final verified = "assets/verified.png";
final uploadbtnimg = "assets/uploadbtnimg.png";
final removeimg = "assets/removeimg.png";
final kr_icon = "assets/Kr.png";
final immi_icon = "assets/Immi_icon.png";
final change_availibity_icon = "assets/change_avalibilty.png";
final company_no_icon = "assets/company_no.png";

final check_iconsvg =
    '''<svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.0781 6.09375L6.63867 9.375L4.92188 7.73438" stroke="#52A9D8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M7.5 13.125C10.6066 13.125 13.125 10.6066 13.125 7.5C13.125 4.3934 10.6066 1.875 7.5 1.875C4.3934 1.875 1.875 4.3934 1.875 7.5C1.875 10.6066 4.3934 13.125 7.5 13.125Z" stroke="#52A9D8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>''';
final upload_iconsvg =
    '''<svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect width="64" height="64" rx="9" fill="#52A9D8"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M42.8243 25.3042H42.9547C43.9811 25.3043 44.9973 25.513 45.9452 25.9181C46.893 26.3233 47.754 26.917 48.4786 27.6652C49.9442 29.1774 50.7672 31.2262 50.7672 33.3623C50.7672 35.4983 49.9442 37.5472 48.4786 39.0594C47.754 39.8076 46.893 40.4013 45.9452 40.8064C44.9973 41.2116 43.9811 41.4202 42.9547 41.4204H37.7492V38.7343H42.9547C44.2984 38.6725 45.5671 38.0794 46.4967 37.0788C47.4263 36.0781 47.9451 34.7469 47.9451 33.3623C47.9451 31.9777 47.4263 30.6465 46.4967 29.6458C45.5671 28.6451 44.2984 28.0521 42.9547 27.9902H40.5698L40.2489 25.6883C40.0531 24.2461 39.4054 22.9091 38.4041 21.8803C37.4029 20.8516 36.1029 20.1874 34.7015 19.9885C33.2994 19.7913 31.8731 20.0732 30.6415 20.7908C29.4099 21.5084 28.441 22.6221 27.8835 23.9611L27.0146 26.0079L24.9037 25.5002C24.4212 25.377 23.9265 25.3112 23.4294 25.3042C21.7021 25.3042 20.0452 26.0106 18.8266 27.2703C17.9185 28.2103 17.3006 29.4057 17.0506 30.7061C16.8007 32.0066 16.9297 33.3541 17.4216 34.5793C17.9135 35.8045 18.7463 36.8526 19.8153 37.5919C20.8842 38.3312 22.1416 38.7287 23.4294 38.7343H29.937V41.4204H23.4294C22.137 41.4323 20.857 41.1606 19.6746 40.6234C18.4922 40.0861 17.4346 39.2956 16.5722 38.3046C15.2684 36.8099 14.4636 34.9247 14.2758 32.9251C14.088 30.9256 14.527 28.9166 15.5285 27.1924C16.1918 26.0501 17.0834 25.066 18.1441 24.3051C19.2048 23.5443 20.4105 23.0242 21.6812 22.7793C22.9493 22.5375 24.2566 22.5725 25.5116 22.8894C26.3025 21.0253 27.6615 19.4771 29.3831 18.4788C31.1047 17.4804 33.0953 17.0864 35.0538 17.3562C37.0131 17.6291 38.8323 18.5531 40.2348 19.9877C41.6374 21.4223 42.5466 23.289 42.8243 25.3042ZM38.485 35.6535L35.0564 32.1267V46.728H32.4628V32.2234L29.1281 35.6561L27.2833 33.7544L32.8829 27.9902H34.7302L40.3298 33.7544L38.485 35.6535Z" fill="white"/>
</svg>
''';
final company_no_iconsvg =
    '''<svg width="18" height="24" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.108 15.663C6.07916 15.8599 6.12972 16.0602 6.24858 16.2199C6.36743 16.3795 6.54483 16.4854 6.74175 16.5142C6.93867 16.5431 7.13899 16.4925 7.29863 16.3737C7.45827 16.2548 7.56416 16.0774 7.593 15.8805L7.722 15H9.582L9.483 15.663C9.45416 15.8599 9.50472 16.0602 9.62358 16.2199C9.74243 16.3795 9.91983 16.4854 10.1168 16.5142C10.3137 16.5431 10.514 16.4925 10.6736 16.3737C10.8333 16.2548 10.9392 16.0774 10.968 15.8805L11.097 15H12C12.1989 15 12.3897 14.921 12.5303 14.7803C12.671 14.6397 12.75 14.4489 12.75 14.25C12.75 14.0511 12.671 13.8603 12.5303 13.7197C12.3897 13.579 12.1989 13.5 12 13.5H11.316L11.646 11.25H12.75C12.9489 11.25 13.1397 11.171 13.2803 11.0303C13.421 10.8897 13.5 10.6989 13.5 10.5C13.5 10.3011 13.421 10.1103 13.2803 9.96967C13.1397 9.82902 12.9489 9.75 12.75 9.75H11.865L12.0705 8.355C12.0848 8.25749 12.0797 8.15813 12.0556 8.06258C12.0315 7.96703 11.9888 7.87717 11.9299 7.79812C11.8111 7.63848 11.6337 7.53259 11.4368 7.50375C11.3392 7.48947 11.2399 7.49453 11.1443 7.51865C11.0488 7.54277 10.9589 7.58548 10.8799 7.64433C10.7202 7.76318 10.6143 7.94058 10.5855 8.1375L10.35 9.75H8.49L8.6955 8.355C8.70978 8.25749 8.70472 8.15813 8.6806 8.06258C8.65648 7.96703 8.61377 7.87717 8.55492 7.79812C8.43607 7.63848 8.25867 7.53259 8.06175 7.50375C7.96424 7.48947 7.86488 7.49453 7.76933 7.51865C7.67378 7.54277 7.58392 7.58548 7.50487 7.64433C7.34523 7.76318 7.23934 7.94058 7.2105 8.1375L6.975 9.75H6C5.80109 9.75 5.61032 9.82902 5.46967 9.96967C5.32902 10.1103 5.25 10.3011 5.25 10.5C5.25 10.6989 5.32902 10.8897 5.46967 11.0303C5.61032 11.171 5.80109 11.25 6 11.25H6.7545L6.4245 13.5H5.25C5.05109 13.5 4.86032 13.579 4.71967 13.7197C4.57902 13.8603 4.5 14.0511 4.5 14.25C4.5 14.4489 4.57902 14.6397 4.71967 14.7803C4.86032 14.921 5.05109 15 5.25 15H6.2055L6.108 15.663ZM10.1295 11.25L9.7995 13.5H7.9425L8.2725 11.25H10.1325H10.1295ZM3 0C2.20435 0 1.44129 0.31607 0.87868 0.87868C0.31607 1.44129 0 2.20435 0 3V21C0 21.7956 0.31607 22.5587 0.87868 23.1213C1.44129 23.6839 2.20435 24 3 24H15C15.7956 24 16.5587 23.6839 17.1213 23.1213C17.6839 22.5587 18 21.7956 18 21V3C18 2.20435 17.6839 1.44129 17.1213 0.87868C16.5587 0.31607 15.7956 0 15 0H3ZM3 1.5H15C15.3978 1.5 15.7794 1.65804 16.0607 1.93934C16.342 2.22064 16.5 2.60218 16.5 3V21C16.5 21.3978 16.342 21.7794 16.0607 22.0607C15.7794 22.342 15.3978 22.5 15 22.5H3C2.60218 22.5 2.22064 22.342 1.93934 22.0607C1.65804 21.7794 1.5 21.3978 1.5 21V3C1.5 2.60218 1.65804 2.22064 1.93934 1.93934C2.22064 1.65804 2.60218 1.5 3 1.5Z" fill="#52A9D8"/>
</svg>
''';

//Icons--

final home_active = "assets/Home_actice.png";
final home_deactive = "assets/home_deactive.png";
final person_deactive = "assets/person_deactice.png";
final person_active = "assets/person_active.png";
final timer_active = "assets/timer_active.png";
final timer_deactive = "assets/timer_deactive.png";
final chat_deactive = "assets/chat_deactive.png";
final chat_active = "assets/chat_active.png";

// profile_icon

final profile_changepwd = "assets/profile_changepwd.png";
final profile_faq = "assets/profile_faq.png";
final profile_logout = "assets/profile_logout.png";
final profile_req = "assets/profile_req.png";
final profile_person = "assets/profile_person.png";
final profile_support = "assets/profile_support.png";
final profile_notification = "assets/profile_notification.png";

final height = 0.5;
final width = 0.7;
// final url ="";// TODO Implement this library.