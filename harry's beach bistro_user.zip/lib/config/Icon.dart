import 'package:flutter/cupertino.dart';

class Icons {
  icons(icon) {
    return Icon(icon);
  }
}
