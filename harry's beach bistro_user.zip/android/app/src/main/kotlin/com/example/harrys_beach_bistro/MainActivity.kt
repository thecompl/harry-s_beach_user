package com.example.harrys_beach_bistro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
